import { Injectable } from '@angular/core';
import {HttpClient}from '@angular/common/http';
import {map} from 'rxjs/operators';
import 'rxjs/add/operatior/map';



@Injectable()
export class WeatherService{
    apiKey ='c0c4e1ec49d0c022d5f6519574a1a2ca';
    url;
    
    
    
    constructor(private http: HttpClient ){

    this.url='http://api.openweathermap.org/data/2.5/forecast?q=';
    
    }
    getWeatherDataByCityName(city,code){
        return this.http.get(this.url+city+','+code+'&APPID='+this.apiKey).map((res)=>{
            res.json();
        })
        
      

    }
}