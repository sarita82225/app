import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { WeatherComponentComponent } from './weather-component/weather-component.component';
import{WeatherService} from './weather.service';
import{HttpClientModule} from '@angular/common/http';
import {RouterModule} from '@angular/router';
import{HomeComponent} from './home/home.component';
import{FormsModule} from '@angular/forms';


const appRoutes=[

  {path:'', component:HomeComponent},
  {path:'Weather', component:WeatherComponentComponent},
  {path:'home', component:HomeComponent}

]


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    WeatherComponentComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule
    
  ],
  providers: [WeatherService],
  bootstrap: [AppComponent]
})
export class AppModule { }
