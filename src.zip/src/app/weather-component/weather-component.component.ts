import { Component, OnInit } from '@angular/core';
import { WeatherService } from '../weather.service';


@Component({
  selector: 'app-weather-component',
  templateUrl: './weather-component.component.html',
  styleUrls: ['./weather-component.component.css']
})
export class WeatherComponentComponent implements OnInit {
  location={
    city:'london',
    code:'london'
  }

weatherData:any;
  constructor(private weatherService: WeatherService){}
    public cityName:string;
    public temp_celcius:string;
    public weatherKind:string;
    public temp_max:string;
    public temp_min:string;
    public humidity:string;
    public code:string;
    
  

  ngOnInit(){
    this.weatherService.getWeatherDataByCityName(this.location.city,this.location.code).subscribe((response)=>
    {console.log(response);
    })
  }
    save()
    {
         let location={
           city:this.cityName,
           code:this.code
         }
         localStorage.setItem(key:'location'JSON.stringify(location));
    }
  
  }


